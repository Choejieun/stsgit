
package com.peisia.cyphers.matches;


public class Record {

    public String gameTypeId;
    public Integer winCount;
    public Integer loseCount;
    public Integer stopCount;

}
