package com.peisia.cyphers;

import lombok.Data;

@Data
public class AmainDto {
	String username;
}
