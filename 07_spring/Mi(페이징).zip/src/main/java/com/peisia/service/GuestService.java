package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.GuestDto;


public interface GuestService {
//	public ArrayList<GuestDto> getList(); //[1]리스트
	public ArrayList<GuestDto> getList(int currentPage); //[1]리스트
	public GuestDto read(long bno); //[2]읽기
	public void del(long bno);	//[3]삭제
	public void write(GuestDto dto);//[4].방명록-write
	public void modify(GuestDto dto);//[5].방명록-modify
}
