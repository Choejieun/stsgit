
package com.peisia.cyphers;

import lombok.Data;

@Data
public class Represent {

    public String characterId;
    public String characterName;

}
