package com.peisia.dto;

import lombok.Data;

@Data
public class Dto {
	 int limitIndex=0;
     int PAGE_LINK_AMOUNT = 4;
     int BLOCK_LINK_AMOUNT = 3;

//    public int getPAGE_LINK_AMOUNT() {
//        return PAGE_LINK_AMOUNT;
//    }
//
//    public int getBLOCK_LINK_AMOUNT() {
//        return BLOCK_LINK_AMOUNT;
//    }
}
