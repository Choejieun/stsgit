
package com.peisia.cyphers.playeridLoad;

import lombok.Data;

@Data
public class Record {

    public String gameTypeId;
    public Integer winCount;
    public Integer loseCount;
    public Integer stopCount;

}
