package com.peisia.dto;

import lombok.Data;

@Data
public class MemberDto {
    private String id;
    private String pw;

//    public int getPAGE_LINK_AMOUNT() {
//        return PAGE_LINK_AMOUNT;
//    }
//
//    public int getBLOCK_LINK_AMOUNT() {
//        return BLOCK_LINK_AMOUNT;
//    }
}
