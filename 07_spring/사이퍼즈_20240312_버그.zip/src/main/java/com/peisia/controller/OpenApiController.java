package com.peisia.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

// Log4j 어노테이션을 사용하여 로그를 기록할 Logger 객체를 생성
@Log4j
// 이 컨트롤러 클래스의 요청 매핑(prefix)을 "/test/*"로 설정. 프로젝트 루트 경로 이하의 "/test" 상위 폴더로 진입 시 이 컨트롤러로 요청이 전달됨.
@RequestMapping("/test/*")
// Lombok의 @AllArgsConstructor를 사용하여 필드 값을 매개변수로 하는 생성자를 자동으로 생성. 스프링이 객체를 관리할 때 이 생성자를 활용.
@AllArgsConstructor
// 이 클래스를 컨트롤러로서 동작하도록 Spring에게 알림.
@Controller
public class OpenApiController {
	
	// GET 방식으로 "/test/test" 경로에 대한 요청을 처리하는 메서드
	@GetMapping("/test")
	public void cyphersSearchPage() throws IOException {
		// 로그에 "rsfs" 메시지 기록
		log.info("rsfs");
		
		// API 호출에 필요한 서비스 키 설정
		String serviceKey = "7ff23dcb-37e8-44e9-989e-f18780fc8ed4";
		// API 호출을 위한 URL 생성
		StringBuilder urlBuilder = new StringBuilder("http://api.kcisa.kr/openapi/API_CNV_060/request"); /*URL*/
		// URL에 서비스 키 및 기타 파라미터 추가
		urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "="+serviceKey); /*서비스키*/
		urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*세션당 요청레코드수*/
		urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("0", "UTF-8")); /*페이지수*/
		urlBuilder.append("&" + URLEncoder.encode("keyword","UTF-8") + "=" + URLEncoder.encode("검색어", "UTF-8")); /*검색어*/
		// URL 객체 생성
		URL url = new URL(urlBuilder.toString());
		// HTTP 연결 객체 생성
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();

		// HTTP 요청 메소드 설정
		conn.setRequestMethod("GET");
		// 요청 헤더 설정
		conn.setRequestProperty("Content-Type", "application/json");
		
		// HTTP 응답 코드 출력
		System.out.println("Response code: " + conn.getResponseCode());
		// 응답 헤더의 Content-type 출력
		System.out.println("Response code22: " + conn.getRequestProperty("Content-Type"));
		String contentType = conn.getHeaderField("Content-Type");

		// 응답 헤더 출력
		Map<String, java.util.List<String>> headerFields = conn.getHeaderFields();
		for (Map.Entry<String, java.util.List<String>> entry : headerFields.entrySet()) {
			String key = entry.getKey();
			java.util.List<String> value = entry.getValue();
			System.out.println(key + ": " + value);
		}
		

		BufferedReader rd;
		// HTTP 응답 코드가 200 ~ 300 사이인 경우
		if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
			// 응답 내용을 읽어올 BufferedReader 객체 생성
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		} else {
			// 에러 스트림으로부터 읽어올 BufferedReader 객체 생성
			rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
		}

		// 응답 내용을 담을 StringBuilder 객체 생성
		StringBuilder sb = new StringBuilder();
		String line;
		// BufferedReader를 이용하여 응답 내용을 한 줄씩 읽어서 StringBuilder에 추가
		while ((line = rd.readLine()) != null) {
			sb.append(line);
		}
		// BufferedReader 닫기
		rd.close();
		// HTTP 연결 해제
		conn.disconnect();
		// 응답 내용 출력
		System.out.println(sb.toString());

	}
}
