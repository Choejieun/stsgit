
package com.peisia.cyphers;

import java.util.List;

import lombok.Data;
@Data
public class CyphersDto {

    public List<Row> rows;

}
