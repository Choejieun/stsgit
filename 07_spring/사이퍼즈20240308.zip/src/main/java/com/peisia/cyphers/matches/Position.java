
package com.peisia.cyphers.matches;

import java.util.List;

public class Position {

    public String name;
    public String explain;
    public List<Attribute> attribute;

}
