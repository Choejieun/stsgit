
package com.peisia.cyphers.matches.moreInfo;

import java.util.List;

import lombok.Data;

@Data
public class Position {

    public String name;
    public String explain;
    public List<Attribute> attribute;

}
