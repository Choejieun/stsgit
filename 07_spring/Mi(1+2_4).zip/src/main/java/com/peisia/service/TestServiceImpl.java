package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.mapper.TestMapper;
import com.peisia.spring.dto.TestDto;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class TestServiceImpl implements TestService { //부서배정을 하는 곳
	
	@Setter(onMethod_ = @Autowired)
	private TestMapper mapper;	
	
	@Override
	public String getOne() {
		log.info("원테스트 ==========");
		TestDto tvo = mapper.getData1(); //일 목록에서 일 가져오기
		String one = tvo.getStr_data(); //완성한 일을 옮기는 일
		return one;
	}

	@Override
	public String getTwo() {
		log.info("투테스트============");
		TestDto tvo = mapper.getData2(); //일 목록에서 일 가져오기
		String two = tvo.getStr_data(); //완성한 일을 옮기는 일
		return two;
	}
	
}
