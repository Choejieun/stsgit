
package com.peisia.cyphers.matches.moreInfo;

import java.util.List;

import lombok.Data;
@Data
public class Team {

    public String result;
    public List<String> players;

}
