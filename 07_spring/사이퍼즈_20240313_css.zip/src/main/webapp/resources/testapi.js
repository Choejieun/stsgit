window.onload=function(){
	var cat1_area = document.getElementById("cat1_area");
	var cat2_area = document.getElementById("cat2_area");
	var dog1_area = document.getElementById("dog1_area");
					
	var xhr = new XMLHttpRequest();				
	var a = document.getElementById("cat1");				
	a.addEventListener("click", function() {				
		xhr.open('GET', '/api/catOne'); // HTTP 메서드와 요청 URL 설정. todo: 현 컨텍스트path에 맞춰 수정할 것			
		xhr.send(); // 요청 보내기			
		xhr.onload = function() {			
			if (xhr.status === 200) { // 응답 상태 확인		
				console.log(xhr.responseText); // 응답 데이터 출력	
				alert(xhr.responseText);
				var x = JSON.parse(xhr.responseText);
				var v = "응가쟁이 : "+x.name+"싼 똥 : "+x.age;
				cat1_area.innerHTML = xhr.responseText+"ㅎㅇ"+v;	
			} else {		
				console.error(xhr.statusText); // 오류 메시지 출력	
			}		
		};			
	});				
	var b = document.getElementById("cat2");				
	b.addEventListener("click", function() {				
		xhr.open('GET', '/api/catTwo'); // HTTP 메서드와 요청 URL 설정. todo: 현 컨텍스트path에 맞춰 수정할 것			
		xhr.send(); // 요청 보내기			
		xhr.onload = function() {			
			if (xhr.status === 200) { // 응답 상태 확인		
				var jo = JSON.parse(xhr.responseText);	
				var s = "고양이름:"+jo.name+" 고양이나이:"+jo.age;	
				alert(s);	
				cat2_area.innerHTML = s;
			} else {		
				console.error(xhr.statusText); // 오류 메시지 출력	
			}		
		};			
					
	});	
	
	var c = document.getElementById("dog1");				
	c.addEventListener("click", function() {				
		xhr.open('GET', '/api/dogOne'); // HTTP 메서드와 요청 URL 설정. todo: 현 컨텍스트path에 맞춰 수정할 것			
		xhr.send(); // 요청 보내기			
		xhr.onload = function() {			
			if (xhr.status === 200) { // 응답 상태 확인		
				var dog = JSON.parse(xhr.responseText);	
				var doghtml = "사실:"+dog.name+" 달마시안:"+dog.age;	
				alert(doghtml);	
				dog1_area.innerHTML = doghtml;
			} else {		
				console.error(xhr.statusText); // 오류 메시지 출력	
			}		
		};			
					
	});    

	// var box_0_img = document.getElementById("box_0_img");
	// var box0 = document.getElementById("box_0");				
	// box0.addEventListener("click", function() {				
	// 	xhr.open('GET', '/api/box0'); // HTTP 메서드와 요청 URL 설정. todo: 현 컨텍스트path에 맞춰 수정할 것			
	// 	xhr.send(); // 요청 보내기			
	// 	xhr.onload = function() {			
	// 		if (xhr.status === 200) { // 응답 상태 확인		
	// 			var box0 = JSON.parse(xhr.responseText);	
	// 			var box0html = "<img src='/resources/img/"+box0.name+"'>";	
	// 			// alert(box0html);	
	// 			box_0_img.innerHTML = box0html;
	// 		} else {		
	// 			console.error(xhr.statusText); // 오류 메시지 출력	
	// 		}		
	// 	};			
					
	// });    
	
    // 첫 번째 상자 클릭 시 실행될 함수
	var box0 = document.getElementById("box_0");				
	box0.addEventListener("click", loadBox0);

	var box1 = document.getElementById("box_1");
	box1.addEventListener("click", loadBox1);
	
	var box2 = document.getElementById("box_2");
	box2.addEventListener("click", loadBox2);
	
	var box3 = document.getElementById("box_3");
	box3.addEventListener("click", loadBox3);

    function loadBox0() {
        xhr.open('GET', '/api/box0'); // HTTP 메서드와 요청 URL 설정. todo: 현 컨텍스트path에 맞춰 수정할 것			
        xhr.send(); // 요청 보내기			
        xhr.onload = function() {			
            if (xhr.status === 200) { // 응답 상태 확인		
                var box0 = JSON.parse(xhr.responseText);	
                var box0html = "<img src='/resources/img/"+box0.name+"'>";	
                box_0_img.innerHTML = box0html;
            } else {		
                console.error(xhr.statusText); // 오류 메시지 출력	
            }		
        };			
    }

    // 페이지 로드 후 3초 후에 첫 번째 상자 정보 로드
    // setTimeout(loadBox0, 3000);
    // 매 3초마다 상자 정보 로드
    setInterval(loadBox0, 1000, 4000);
    setInterval(loadBox1, 2000, 6000);
    setInterval(loadBox2, 3000, 4000);
    setInterval(loadBox3, 4000, 4000);


	box0.addEventListener("click", function() {
		// 클릭 이벤트가 발생하면 10초 후의 요청은 취소되고 즉시 새로운 요청이 보내짐
		clearTimeout(loadBox0);
		loadBox0();
	});
	box1.addEventListener("click", function() {
		// 클릭 이벤트가 발생하면 10초 후의 요청은 취소되고 즉시 새로운 요청이 보내짐
		clearTimeout(loadBox1);
		loadBox1();
	});
	box2.addEventListener("click", function() {
		// 클릭 이벤트가 발생하면 10초 후의 요청은 취소되고 즉시 새로운 요청이 보내짐
		clearTimeout(loadBox2);
		loadBox2();
	});
	box3.addEventListener("click", function() {
		// 클릭 이벤트가 발생하면 10초 후의 요청은 취소되고 즉시 새로운 요청이 보내짐
		clearTimeout(loadBox3);
		loadBox3();
	});

	function loadBox1() {
		xhr.open('GET', '/api/box1');
		xhr.send();
		xhr.onload = function() {
			if (xhr.status === 200) {
				var box1 = JSON.parse(xhr.responseText);
				var box1html = "<img src='/resources/img/" + box1.name + "'>";
				box_0_img.innerHTML = box1html;
			} else {
				console.error(xhr.statusText);
			}
		};
	}
	
	function loadBox2() {
		xhr.open('GET', '/api/box2');
		xhr.send();
		xhr.onload = function() {
			if (xhr.status === 200) {
				var box2 = JSON.parse(xhr.responseText);
				var box2html = "<img src='/resources/img/" + box2.name + "'>";
				box_0_img.innerHTML = box2html;
			} else {
				console.error(xhr.statusText);
			}
		};
	}
	
	function loadBox3() {
		xhr.open('GET', '/api/box3');
		xhr.send();
		xhr.onload = function() {
			if (xhr.status === 200) {
				var box3 = JSON.parse(xhr.responseText);
				var box3html = "<img src='/resources/img/" + box3.name + "'>";
				box_0_img.innerHTML = box3html;
			} else {
				console.error(xhr.statusText);
			}
		};
	}
	

	
					  
}					