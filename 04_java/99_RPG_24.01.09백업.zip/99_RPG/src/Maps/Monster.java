package Maps;

public class Monster {
static public void run() {
	
	
	
}	}//run
