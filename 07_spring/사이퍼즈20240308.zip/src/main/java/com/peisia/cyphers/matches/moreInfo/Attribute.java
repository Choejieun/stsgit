
package com.peisia.cyphers.matches.moreInfo;


public class Attribute {

    public Integer level;
    public String id;
    public String name;

}
