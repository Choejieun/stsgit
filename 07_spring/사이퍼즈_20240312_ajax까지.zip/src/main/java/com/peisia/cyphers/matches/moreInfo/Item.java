
package com.peisia.cyphers.matches.moreInfo;


public class Item {

    public String itemId;
    public String itemName;
    public String slotCode;
    public String slotName;
    public String rarityCode;
    public String rarityName;
    public String equipSlotCode;
    public String equipSlotName;

}
