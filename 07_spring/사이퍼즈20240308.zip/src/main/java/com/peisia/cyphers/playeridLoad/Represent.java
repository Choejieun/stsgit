
package com.peisia.cyphers.playeridLoad;


public class Represent {

    public String characterId;
    public String characterName;

}
