
package com.peisia.cyphers.matches.moreInfo;


public class Map {

    public String mapId;
    public String name;

}
