
package com.peisia.cyphers.matches;


public class Date {

    public String start;
    public String end;

}
