
package com.peisia.cyphers.matches.moreInfo;


public class Map__1 {

    public String mapId;
    public String name;

}
