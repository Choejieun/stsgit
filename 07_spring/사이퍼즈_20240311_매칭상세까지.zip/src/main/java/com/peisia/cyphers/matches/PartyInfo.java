
package com.peisia.cyphers.matches;

import lombok.Data;

@Data
public class PartyInfo {

    public String playerId;
    public String nickname;
    public String characterId;
    public String characterName;

}
