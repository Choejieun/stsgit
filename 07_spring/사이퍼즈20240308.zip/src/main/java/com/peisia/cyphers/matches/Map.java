
package com.peisia.cyphers.matches;

import lombok.Data;

@Data
public class Map {

    public String mapId;
    public String name;

}
