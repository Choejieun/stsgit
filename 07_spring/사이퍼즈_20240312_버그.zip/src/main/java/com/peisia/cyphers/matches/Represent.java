
package com.peisia.cyphers.matches;


public class Represent {

    public String characterId;
    public String characterName;

}
