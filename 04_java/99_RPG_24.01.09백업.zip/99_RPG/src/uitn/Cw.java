package uitn;

public class Cw {
	
	String s;
	
	static public void Wn(String s) {
		System.out.println(s);
	}
	static public void W(String s) {
		System.out.print(s);
	}
	static public void Mclosure() {
		Cw.Wn("│─┼─┼─┼─┼─│");
	}
	static public void Mtop() {
		Cw.Wn("┌─────────┐");
	}
	static public void Mbot() {
		Cw.Wn("└─────────┘");
	}
	

}
